// Motel Customer Object with arrays and sub-objects.

const customer = {
  name: 'Jane Smith',
  birthDate: '1989-07-08',
  gender: 'Female',
  roomPreferences: ['Non-smoking', ' King size bed', ' and High floors'],
  paymentMethod: 'Credit Card',
  mailingAddress: {
    street: '123 Duckworth St.',
    city: 'St.Johns',
    province: 'NL',
    postalCode: 'A1A 1X1',
  },
  phoneNumber: '709-555-1234',
  stay: {
    checkInDate: '2024-08-02',
    checkOutDate: '2024-08-05',
  },
};

// Convert birthdate string to date object
const birthDate = new Date(customer.birthDate);
const currDate = new Date();

// Initial calculation of age
let age = currDate.getFullYear() - birthDate.getFullYear();

// Age adjustment if birthday has not occured yet.

if (
  currDate.getMonth() < birthDate.getMonth() ||
  (currDate.getMonth() === birthDate.getMonth() &&
    currDate.getDate() < birthDate.getDate())
);

console.log(`${customer.name} is ${age}`);

// Calculate the duration of stay at the motel.

const checkInDate = new Date(customer.stay.checkInDate);
const checkOutDate = new Date(customer.stay.checkOutDate);

// Calculate the duration of stay in milliseconds.

const stayDurationMs = checkOutDate - checkInDate;

// Calculate milliseconds to days.

const stayDurationDays = stayDurationMs / (1000 * 60 * 60 * 24);

console.log(`Duration of stay: ${stayDurationDays} days`);

// Description

const Description = `
  The Motel guest ${customer.name} is a ${age} year old ${customer.gender}
  who was born in ${customer.birthDate}. Her Motel room preferences are 
  ${customer.roomPreferences}. She paid by ${customer.paymentMethod}.
  Her mailing address is
  
  
  ${customer.mailingAddress.street}
  ${customer.mailingAddress.city},
  ${customer.mailingAddress.province},
  ${customer.mailingAddress.postalCode}.
  Her phone number is ${customer.phoneNumber}.
  
  
  The check-in date for the Motel is ${checkInDate}.
  The check-out date for the Motel is ${checkOutDate}.
  Her duration of stay is ${stayDurationDays} days!
  `;

console.log(Description);

document.write(Description);
